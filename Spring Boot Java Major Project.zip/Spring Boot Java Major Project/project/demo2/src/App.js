import React from 'react'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import AdminDash from './components/admin/AdminDash';
import Home from './components/starters/Home';
import UserDash from './components/user/UserDash';



function App() {
  return (
    <Router>
    <div className='App'>
      <Routes>
       <Route exact path="/" element={<Home />} />
       {/* <Route exact path="/login" element={<Login />} /> */}
       <Route exact path="/userdash" element={<UserDash />} />
       <Route exact path="/admindash" element={<AdminDash />}/>
       {/* <Route exact path="/register" element={<SignUp1 />} />
       <Route exact path="/addflight" element={<AddFlight1/>} />
       <Route exact path="/viewflights" element={<ViewFlights />} /> */}
       {/* <Route exact path="/aboutus" element={<AboutUs />} /> */}
       {/* <Route exact path="/peseatdisplay" element={<PESeatDisplay />} /> */}
       {/* <Route exact path="/viewflightdetail" element={< Viewflightdetail />} /> */}
       {/* <Route exact path="/ticketbooking" element={< TicketBooking />} /> */}
       {/* <Route exact path="/viewusers" element={< ViewUsers />} /> */}
       {/* <Route exact path="/deleteuser" element={< DeleteUser />} />
       <Route exact path="/deleteflights" element={< DeleteFlight />} />
       <Route exact path="/viewprofile" element={< ViewProfile />} />
       <Route exact path="/datatable" element={< Datatable />} />
   
       <Route exact path="/udatatable" element={< FlightTable />} />
       <Route exact path="/uviewflight" element={< ViewFlight />} />
       <Route exact path="/addbank" element={< AddBank />} />
       <Route exact path="/seatbook" element={< SeatBook />} />
       <Route exact path="/peseatdisplay" element={< PESeatDisplay />} />
       <Route exact path="/bseatdisplay" element={< BSeatDisplay />} />
       <Route exact path="/eseatdisplay" element={<Economy />} />
       <Route exact path="/turnover" element={<TurnOver />} />
       <Route exact path="/bookanother" element={<AnotherBooking />} />
       <Route exact path="/bookdemo" element={<BookDemo />} />
       <Route exact path="/paymentpage" element={<Payment />} />
       <Route exact path="/ticketgenerate" element={<TicketGenerate />} />
       <Route exact path="/bookinghistry" element={<BookingHistry />} /> */}
       {/* <Route exact path="/loginwithemail" element={<LoginWithEmail />} /> */}
       {/* <Route exact path="/visitordetail" element={<VisitorDetail />} />
       <Route exact path="/viewbookhistory" element={<ViewBookingHistory />} />
       <Route exact path="/ueditprofile" element={<EditProfile />} /> */}
     </Routes>
    </div>
  </Router>
  );
}

export default App;

import * as React from 'react';
import Box from '@mui/material/Box';
import SwipeableDrawer from '@mui/material/SwipeableDrawer';
import Button from '@mui/material/Button';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import MenuOpenIcon from '@mui/icons-material/MenuOpen';
import HomeIcon from '@mui/icons-material/Home';
import AccessibilityNewIcon from '@mui/icons-material/AccessibilityNew';
import FlightIcon from '@mui/icons-material/Flight';
import FeedbackIcon from '@mui/icons-material/Feedback';
import { Global } from '@emotion/react';

export default function SideDrawerAdmin() {

  const drawerBleeding = 1;

  const [state, setState] = React.useState({
    top: false,
    Menu: false,
    bottom: false,
    right: false,
  });

  const toggleDrawer = (anchor, open) => (event) => {
    if (
      event &&
      event.type === 'keydown' &&
      (event.key === 'Tab' || event.key === 'Shift')
    ) {
      return;
    }

    setState({ ...state, [anchor]: open });
  };


  const list = (anchor) => (
    <Box
      sx={{ width: anchor === 'top' || anchor === 'bottom' ? 'auto' : 250 }}
      role="presentation"
      onClick={toggleDrawer(anchor, false)}
      onKeyDown={toggleDrawer(anchor, false)}
    >
      <Global
        styles={{
          '.MuiDrawer-root > .MuiPaper-root': {
            height: `calc(50% - ${drawerBleeding}px)`,
            overflow: 'visible',
          },
        }}
      />
      <List>
        <br/>
        <Divider/>
        <Button variant="text" disableElevation>&nbsp;&nbsp;<HomeIcon/>&nbsp;&nbsp;&nbsp;Home</Button><br/>
        <Divider/>
        <br/>
        <Divider/>
        <Button variant="text" disableElevation>&nbsp;&nbsp;<AccessibilityNewIcon/>&nbsp;&nbsp;&nbsp;User Management</Button><br/>
        <Divider/>
        <br/>
        <Divider/>
        <Button variant="text" disableElevation>&nbsp;&nbsp;<FlightIcon/>&nbsp;&nbsp;&nbsp;Flight Management</Button><br/>
        <Divider/>
        <br/>
        <Divider/>
        <Button variant="text" disableElevation>&nbsp;&nbsp;<FeedbackIcon/>&nbsp;&nbsp;&nbsp;Complaints</Button><br/>
        <Divider/>
      </List>
    </Box>
  );

  return (
    <div>
      {['Menu'].map((anchor) => (
        <React.Fragment key={anchor}>
          <Button variant="contained" color="secondary" onClick={toggleDrawer(anchor, true)}><MenuOpenIcon/>&nbsp;{anchor}</Button>
          <SwipeableDrawer
            anchor={anchor}
            open={state[anchor]}
            onClose={toggleDrawer(anchor, false)}
            onOpen={toggleDrawer(anchor, true)}
          >
            {list(anchor)}
          </SwipeableDrawer>
        </React.Fragment>
      ))}
    </div>
  );
}

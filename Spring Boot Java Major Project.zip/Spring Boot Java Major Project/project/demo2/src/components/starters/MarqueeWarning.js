import React from 'react'
import { Typography } from '@mui/material'

export const MarqueeWarning = () => {

  return(
    <div>
        <Typography variant="subtitle1" color='#ff7043'>
        Travellers are adviced to carry Vaccination Certificate while travelling !!! &nbsp;&nbsp;&nbsp;&nbsp;
        Please Wear Face Mask While Travelling !!!&nbsp;&nbsp;&nbsp;&nbsp;
        Thank You For Flying With Us.
    </Typography>
    </div>
  )
}

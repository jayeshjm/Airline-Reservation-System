import { AppBar, Button, IconButton, Toolbar, Typography } from '@mui/material'
import AirlinesIcon from '@mui/icons-material/Airlines';
import InstagramIcon from '@mui/icons-material/Instagram';
import FacebookIcon from '@mui/icons-material/Facebook';
import TwitterIcon from '@mui/icons-material/Twitter';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import React from 'react'

export const Footer = () => {
  return (
    <AppBar position="static" sx={{
            width: '100%',
            height: '60px',
            position: 'fixed',
            bottom: 0
    }} >
      <Toolbar>
        <IconButton
            edge="start"
            color="inherit"
        >
          <AirlinesIcon />
        </IconButton>
        <Typography component="div" sx={{ flexGrow: 1 }}>
            © 2022 Cybage Software. React Group 5. All Rights Reserved
        </Typography>
        <Typography>
        Follow Us On
        </Typography>
            <Button variant="contained" disableElevation>
                <InstagramIcon/>
            </Button>
            <Button variant="contained" disableElevation>
                <FacebookIcon/>
            </Button>
            <Button variant="contained" disableElevation>
                <TwitterIcon/>
            </Button>
            <Button variant="contained" disableElevation>
                <LinkedInIcon/>
            </Button>
      </Toolbar>
    </AppBar>

  )
}

import React, { Component } from 'react'
import ReactAwesomeClock from "react-awesome-clock";
import Moment from 'moment';
const formatDate = Moment().format('Do . MMMM . YYYY')


class Clock extends Component {
  state = {date: new Date()}

  

  render() {
    return (
      <div class="date" style={{border: "solid 2px blue"}}>
        <ReactAwesomeClock style={{
            color: "white",
            fontSize: 50,
            textShadow: "0 0 10px grey",
            fontFamily: "Helvetica",
            background: "#42a5f5",
            paddingTop: "10px",
          }} />
        <div style={{
            color: "White",
            fontSize: 30,
            textShadow: "0 0 10px grey",
            fontFamily: "Helvetica",
            background: "#42a5f5",
            paddingLeft: "20px"
            }}> 
            <div style={{ fontSize: 18}}>Date</div>
            {formatDate}
          </div>
      </div>
    );
  }
}

export default Clock;

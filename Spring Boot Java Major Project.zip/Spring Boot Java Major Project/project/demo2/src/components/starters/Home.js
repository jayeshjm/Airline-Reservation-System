import { Box, Grid } from '@mui/material'
import React from 'react'
import UpperHalfHome from './UpperHalfHome';
import { Footer } from './Footer';
import { NavbarHome } from './NavbarHome';
import { LowerHalf } from './LowerHalf';
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';


const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));



function Home() {
  return (
    <Box >
      
      <NavbarHome/>
        {/* <UpperHalfHome />

        <LowerHalf/>

        <Footer/> */}

        <Grid container spacing={{ xs: 0, md: 0 }} columns={{ xs: 8, sm: 12, md: 12 }}>
            {/* <Grid item xs={2} sm={15} md={4}>
                <Item><NavbarHome/></Item>
            </Grid> */}
            <Grid item xs={15} sm={15} md={15}>
                <Item><UpperHalfHome/></Item>
            </Grid>
            <Grid item xs={15} sm={15} md={15}>
                <Item><LowerHalf/></Item>
            </Grid>
            {/* <Grid item xs={2} sm={4} md={4}>
                <Item></Item>
            </Grid> */}
        </Grid>
        <Footer/>
  </Box>
  )
}

export default Home
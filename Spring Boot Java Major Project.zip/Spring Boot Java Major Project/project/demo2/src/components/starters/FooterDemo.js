import { AppBar, Button, IconButton, Paper, Toolbar, Typography } from '@mui/material'
import AirlinesIcon from '@mui/icons-material/Airlines';
import React from 'react'


export const FooterDemo = () => {
  return (
    <Paper sx={{marginTop: 'calc(10% + 6px)',
    width: '100%',
    position: 'fixed',
    bottom: 0
    }} component="footer" square variant="outlined">

      <AppBar position="static"  style={{
        backgroundColor: "#80d8ff"
    }}>
      <Toolbar>
        <IconButton
          size="large"
          edge="start"
          color="inherit"
          aria-label="menu"
        >
          <AirlinesIcon />
        </IconButton>
        <Typography component="div">
            Cybage Software Pvt. Ltd.
            All Rights Reserved
        </Typography>
        <Button variant="contained" color="secondary">
                Login
            </Button>
            <p>&nbsp;&nbsp;&nbsp;</p>
            <Button variant="contained" color="secondary">
                Sign Up
            </Button>
      </Toolbar>
    </AppBar>
    </Paper>
  )
}

import React from 'react'
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import OffersHome from './OffersHome';
import Clock from './Clock';
import Awards from './Awards';





export const LowerHalf = () => {
  return (
    <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2} columns={16}>
        <Grid  xs={8}>
          <OffersHome/>  
        </Grid>
        <Grid  xs={8}>
          <Clock/>
          <Awards/>
        </Grid>
      </Grid>
    </Box>
  )
}

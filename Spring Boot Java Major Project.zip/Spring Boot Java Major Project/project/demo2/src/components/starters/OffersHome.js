import * as React from 'react';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import axios from 'axios'
import { styled } from '@mui/material/styles';

const columns = [
  { id: 'coupon', label: 'Offer Name', minWidth: 60, align: 'center' },
  { id: 'offerName', label: 'Desciption', minWidth: 200, align: 'center' },
];


const StyledTableCell = styled(TableCell)(( ) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: '#42a5f5',
    color: 'white',
  }
}));



export default function OffersHome() {

    const [data, setData] = React.useState([]);

    React.useEffect(() => {
        axios
          .get("http://localhost:8082/getAllOffer/")
          .then((res) => {
            setData(res.data);
            console.log("Result:", data);
          })
          .catch((error) => {
            console.log(error);
          });// eslint-disable-next-line
      }, []);
   
      

  return (
    <Paper sx={{ width: '100%', paddingLeft: '16px' }}>
      
      <TableContainer sx={{ maxHeight: 420 }}>
        <Table stickyHeader aria-label="sticky table">
          <TableHead>
            <TableRow>
              <StyledTableCell align="center" colSpan={3}>
                Available Offers
              </StyledTableCell>
            </TableRow>
            <TableRow>
              {columns.map((column) => (
                <StyledTableCell
                  key={column.id}
                  align={column.align}
                >
                  {column.label}
                </StyledTableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {data.map((row) => {
                return (
                  <TableRow hover role="checkbox" key={row.code}>
                    {columns.map((column) => {
                      const value = row[column.id];
                      return (
                        <TableCell key={column.id} align={column.align}>
                          {column.format && typeof value === 'number' ? column.format(value): value}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                );
              })}
          </TableBody>
        </Table>
      </TableContainer>

    </Paper>
  );
}

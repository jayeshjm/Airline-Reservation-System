import React from 'react'
import IconButton from '@mui/material/IconButton';
import LoginIcon from '@mui/icons-material/Login';
import AppRegistrationIcon from '@mui/icons-material/AppRegistration';
import AirlinesIcon from '@mui/icons-material/Airlines';
import { AppBar, Button, Toolbar, Typography } from '@mui/material'
import Marquee from "react-fast-marquee";
import { MarqueeWarning } from './MarqueeWarning';

export const NavbarHome = () => {
  return (
    <AppBar position="fixed">
    <Toolbar>
      <IconButton
        size="large"
        edge="start"
        color="inherit"
        aria-label="menu"
        sx={{ mr: 2 }}
      >
        <AirlinesIcon />
      </IconButton>
      <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
        Airline Ticket Booking
      </Typography>
          <Button variant="contained" color="secondary" startIcon={<LoginIcon />} href="http://localhost:3000/loginwithemail">
              Login
          </Button>
          <p>&nbsp;&nbsp;&nbsp;</p>
          <Button variant="contained" color="secondary" endIcon={<AppRegistrationIcon />}>
              Sign Up
          </Button>
    </Toolbar>
            <Marquee speed={50} gradientWidth={5} style={{backgroundColor: '#bbdefb'}}>
               <MarqueeWarning/>
            </Marquee>
  </AppBar>
  
  )
}

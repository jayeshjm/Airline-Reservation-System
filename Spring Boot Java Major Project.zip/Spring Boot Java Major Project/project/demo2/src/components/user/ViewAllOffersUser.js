import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import React,{ useState, useEffect }  from 'react';
import axios from 'axios';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import { Button } from "@mui/material";
import DoneIcon from '@mui/icons-material/Done';


  
export default function ViewAllOffersUser() {
 const [data, setData] = useState([]);
  
 useEffect(() => {
   axios
     .get("http://localhost:8082/getAllOffer/")
     .then((res) => {
       setData(res.data);
     })
     .catch((error) => {
       console.log(error);
     });
 }, []);


const handleDelete = (offerID) => {
  console.log(offerID);
//   window.location.reload(false);
  axios
  .delete("http://localhost:8082/deleteOffer/" +offerID)
  .then((response)=>{
    console.log(response.data)})
  .catch(error=> {
    console.log("error")});
}

  
 return (
   <TableContainer component={Paper}>
     <Table aria-label="simple table" stickyHeader>
       <TableHead>
         <TableRow>
         <TableCell align="left">Offer Id</TableCell>
           <TableCell align="center">Offer Name</TableCell>
           <TableCell align="center">Details</TableCell>
         </TableRow>
       </TableHead>
       <TableBody>
         {data.map((post) => (
           <TableRow key={post.offerID}>
                <TableCell align="left">{post.offerID}</TableCell>
                <TableCell align="center">{post.coupon}</TableCell>
                <TableCell align="center">{post.offerName}</TableCell>
           </TableRow>
         ))}
       </TableBody>
     </Table>
   </TableContainer>
 );
}
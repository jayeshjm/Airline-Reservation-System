import { Box } from '@mui/material'
import React from 'react'
import { Footer } from '../starters/Footer';
import NavbarForUser from './NavbarForUser';
import UserDashContent from './UserDashContent';


function UserDash() {
  return (
    <Box >
        <NavbarForUser/>
        <UserDashContent/>
        <Footer/>
  </Box>
  )
}
export default UserDash
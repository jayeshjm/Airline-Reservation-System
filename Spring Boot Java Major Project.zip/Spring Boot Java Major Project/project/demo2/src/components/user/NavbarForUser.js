import * as React from 'react';
import { Box } from '@mui/material';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { useNavigate  } from "react-router-dom";
import LogoutIcon from '@mui/icons-material/Logout';
import DashboardIcon from '@mui/icons-material/Dashboard';

export default function NavbarForUser() {

  const navigate = useNavigate();
    
    const onLogout = () => {
      sessionStorage.removeItem('user');
      alert('You have been logout');
      navigate('/loginwithemail');
    };

  

  return (
    <Box sx={{ flexGrow: 1 }}>
    <AppBar position="static">
      <Toolbar>
        <Typography variant="h4" component="div" sx={{ flexGrow: 1 }}>
          <DashboardIcon/> &nbsp;&nbsp;User Home
        </Typography>
        <Button variant="contained" color="secondary" onClick={onLogout}>Log Out&nbsp;&nbsp;<LogoutIcon/></Button>
      </Toolbar>
    </AppBar>
  </Box>
  );
}

import * as React from 'react';
import Box from '@mui/material/Box';
import Tab from '@material-ui/core/Tab';
import TabContext from '@material-ui/lab/TabContext';
import TabList from '@material-ui/lab/TabList';
import TabPanel from '@material-ui/lab/TabPanel';
import LockedUsers from './LockedUsers';
import ViewFlights from './ViewFlights';
import ViewComplaints from './ViewComplaints';
import ViewUsers from './ViewUsers';
import ViewAllBookings from './ViewAllBookings';
import ViewFeedback from './ViewFeedback';
import ViewAllOffers from './ViewAllOffers';

export default function AdminDashContent() {
  const [value, setValue] = React.useState('1');

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: '100%', typography: 'body1' }}>
      <TabContext value={value}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <TabList onChange={handleChange} aria-label="lab API tabs example">
            <Tab label="All Users" value="1" />
            <Tab label="Locked Users" value="2" />
            <Tab label="All Flights" value="3" />
            <Tab label="View All Bookings" value="4" />
            <Tab label="Complaints" value="5" />
            <Tab label="Feedbacks" value="6" />
            <Tab label="Offers" value="7" />
          </TabList>
        </Box>
        <TabPanel value="1"><ViewUsers/></TabPanel>
        <TabPanel value="2"><LockedUsers/></TabPanel>
        <TabPanel value="3"><ViewFlights/></TabPanel>
        <TabPanel value="4"><ViewAllBookings/></TabPanel>
        <TabPanel value="5"><ViewComplaints/></TabPanel>
        <TabPanel value="6"><ViewFeedback/></TabPanel>
        <TabPanel value="7"><ViewAllOffers/></TabPanel>
      </TabContext>
      
    </Box>
  );
}

import { Box } from '@mui/material'
import React from 'react'
import NavbarForAdmin from './NavbarForAdmin';
import { Footer } from '../starters/Footer';
import AdminDashContent from './AdminDashContent';


function AdminDash() {
  return (
    <Box >
        <NavbarForAdmin/>
        <AdminDashContent/>
        
        <Footer/>
  </Box>
  )
}
export default AdminDash
import axios from 'axios';
import React from 'react'
import { useForm } from 'react-hook-form';
import { useParams } from 'react-router-dom';

export default function BookTicket ()  {
     //const {id}=useParams();
    const {register,handleSubmit,formState:{errors}}=useForm();
    const onSubmit = data =>{
        console.log(data);
        axios
        .post("http://localhost:8082/addBooking" , data)
        .then(response => console.log(response.data)).catch((error=>console.log("error")));
        
    }
  return (

    
     <form onSubmit={handleSubmit(onSubmit)}>
      
      <label htmlFor="bookingId">Flight Id</label>
      <input id="bookingId" {...register('bookingId', { required: false, maxLength: 3})} />
      {/* {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> } */}
      
      <br></br>
      <label htmlFor="bookingDate">bookingDate </label>
      <input id="bookingDate" {...register('bookingDate', { required: true, maxLength: 10})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }

      <br></br>
      <label htmlFor="amount">amount </label>
      <input id="amount" {...register('amount', { required: true, maxLength: 10})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }

      <br></br>
      <label htmlFor="countPassenger">countPassenger</label>
      <input id="countPassenger" {...register('countPassenger', { required: true, maxLength: 30})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }
     
      <br></br>
      <label htmlFor="flightId">flightId</label>
      <input type="flightId" id="flightId" {...register('flightId', { required: true, maxLength: 3})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }

      <br></br>
      <label htmlFor="passenger1">passenger1</label>
      <input id="passenger1" {...register('passenger1', { required: true, maxLength: 10})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }

      <br></br>
      <label htmlFor="passenger2">passenger2 </label>
      <input id="passenger2" {...register('passenger2', { required: true, maxLength: 10})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }

      <br></br>
      <label htmlFor="passenger3">passenger3 </label>
      <input id="passenger3" {...register('passenger3', { required: true, maxLength: 20})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }

      <br></br>
      <label htmlFor="userId">userId </label>
      <input id="userId" {...register('userId', { required: true, maxLength: 20})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }


      <input type="submit" />
  
    </form>
  )
}



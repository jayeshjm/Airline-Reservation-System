import React, { Component } from 'react'
import axios from 'axios'
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { Button } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';


export default class LockedUsers extends Component {
    constructor(props){
            super(props)

            this.state = {
                posts: [],
                errorMsg:''
            }
        }

        componentDidMount() {
            axios
            .get('http://localhost:8082/getAllLockedUsers/')
            .then(response => {
                console.log(response)
                this.setState({ posts: response.data})
            })
            .catch(error => {
                console.log(error)
                this.setState({errorMsg: 'error retrieving data'})
            })
        }


        
    
  render() {
    const { posts } = this.state;
    

    const StyledTableCell = styled(TableCell)(({ theme }) => ({
        [`&.${tableCellClasses.head}`]: {
          backgroundColor: theme.palette.common.black,
          color: theme.palette.common.white,
        },
        [`&.${tableCellClasses.body}`]: {
          fontSize: 14,
        },
      }));
      
      const StyledTableRow = styled(TableRow)(({ theme }) => ({
        '&:nth-of-type(odd)': {
          backgroundColor: theme.palette.action.hover,
        },
        // hide last border
        '&:last-child td, &:last-child th': {
          border: 0,
        },
      }));
     const handleDelete = (userId) => {
      console.log(userId);
      axios
      .get("http://localhost:8082/unlockUser/" +userId)
      .then((response)=>{
        console.log(response.data)})
      .catch(error=> {
        console.log("error")});
    }

    return (

        <TableContainer component={Paper}>
        <Table sx={{ minWidth: 700 }} aria-label="customized table">
          <TableHead>
            <TableRow>
              <StyledTableCell>User Name</StyledTableCell>
              <StyledTableCell align="center">User Email</StyledTableCell>
              <StyledTableCell align="center">Phone No.</StyledTableCell>
              <StyledTableCell align="center">Date of Birth</StyledTableCell>
              <StyledTableCell align="center">Gender</StyledTableCell>
              <StyledTableCell align="center">Failed Attempts</StyledTableCell>
              <StyledTableCell align="center">Role</StyledTableCell>
              <StyledTableCell align="center">Action</StyledTableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {posts.map((post) => (
              <StyledTableRow key={post.id}>
                <StyledTableCell component="th" scope="row">
                  {post.name}
                </StyledTableCell>
                <StyledTableCell align="center">{post.email}</StyledTableCell>
                <StyledTableCell align="center">{post.phone}</StyledTableCell>
                <StyledTableCell align="center">{post.dob}</StyledTableCell>
                <StyledTableCell align="center">{post.gender}</StyledTableCell>
                <StyledTableCell align="center">{post.attempt}</StyledTableCell>
                <StyledTableCell align="center">{post.role}</StyledTableCell>
                <StyledTableCell align="center">
                    <Button variant="outlined" startIcon={<DeleteIcon />} onClick={() => handleDelete(post.userId)}>
                        Unlock
                    </Button>
                </StyledTableCell>
              </StyledTableRow>
            ))}
          </TableBody>
        </Table>
        </TableContainer>
    )
  }
}

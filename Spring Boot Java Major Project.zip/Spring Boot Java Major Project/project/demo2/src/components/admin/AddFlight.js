import axios from 'axios';
import React from 'react'
import { useForm } from 'react-hook-form';
import { useParams } from 'react-router-dom';

export default function AddFlight ()  {
     //const {id}=useParams();
    const {register,handleSubmit,formState:{errors}}=useForm();
    const onSubmit = data =>{
        console.log(data);
        axios
        .post("http://localhost:8082/addFlight" , data)
        .then(response => console.log(response.data)).catch((error=>console.log("error")));
        
    }
  return (

    
     <form onSubmit={handleSubmit(onSubmit)}>
      
      <label htmlFor="flightId">Flight Id</label>
      <input id="flightId" {...register('flightId', { required: false, maxLength: 3})} />
      {/* {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> } */}
      
      <br></br>
      <label htmlFor="arrival">Arrival </label>
      <input id="arrival" {...register('arrival', { required: true, maxLength: 10})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }

      <br></br>
      <label htmlFor="departure">Departure </label>
      <input id="departure" {...register('departure', { required: true, maxLength: 10})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }

      <br></br>
      <label htmlFor="flightName">flightName</label>
      <input id="flightName" {...register('flightName', { required: true, maxLength: 30})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }
     
      <br></br>
      <label htmlFor="capacity">capacity</label>
      <input type="number" id="capacity" {...register('capacity', { required: true, maxLength: 3})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }

      <br></br>
      <label htmlFor="schedule">schedule</label>
      <input id="schedule" {...register('schedule', { required: true, maxLength: 10})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }

      <br></br>
      <label htmlFor="flightDate">flightDate </label>
      <input id="flightDate" {...register('flightDate', { required: true, maxLength: 10})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }

      <br></br>
      <label htmlFor="source">source </label>
      <input id="source" {...register('source', { required: true, maxLength: 20})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }

      <br></br>
      <label htmlFor="destination">destination </label>
      <input id="destination" {...register('destination', { required: true, maxLength: 20})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }

      <br></br>
      <label htmlFor="price">price </label>
      <input type="number" id="price" {...register('price', { required: true, maxLength: 8})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }

      <br></br>
      <label htmlFor="fares">fares </label>
      <input id="fares" {...register('fares', { required: true, maxLength: 10})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }

      <br></br>
      <label htmlFor="trip">trip </label>
      <input id="trip" {...register('trip', { required: true, maxLength: 10})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }

      <br></br>
      <label htmlFor="type">type </label>
      <input id="type" {...register('type', { required: true, maxLength: 10})} />
      {errors.name && errors.name.type === "required" && <span>This is required</span>}
      {errors.name && errors.name.type === "maxLength" && <span>Max length exceeded</span> }


      <input type="submit" />
  
    </form>
  )
}



import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import React,{ useState, useEffect }  from 'react';
import axios from 'axios';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import { Button } from "@mui/material";
import DoneIcon from '@mui/icons-material/Done';


  
export default function ViewFeedback() {
 const [data, setData] = useState([]);
  
 useEffect(() => {
   axios
     .get("http://localhost:8082/getAllFeedbacks/")
     .then((res) => {
       setData(res.data);
     })
     .catch((error) => {
       console.log(error);
     });
 }, []);


const handleDelete = (complaintId) => {
  console.log(complaintId);
  axios
  .delete("http://localhost:8082/deleteComplaint/" +complaintId)
  .then((response)=>{
    console.log(response.data)})
  .catch(error=> {
    console.log("error")});
}

  
 return (
   <TableContainer component={Paper}>
     <Table aria-label="simple table" stickyHeader>
       <TableHead>
         <TableRow>
         <TableCell align="left">feedback Id</TableCell>
           <TableCell align="center">Email</TableCell>
           <TableCell align="center">Feedback Date</TableCell>
           <TableCell align="center">Query</TableCell>
           <TableCell align="center">Rating (out of 5)</TableCell>
           <TableCell align="center">User Id</TableCell>
           <TableCell align="center">Delete</TableCell>
         </TableRow>
       </TableHead>
       <TableBody>
         {data.map((post) => (
           <TableRow key={post.feedbackId}>
                <TableCell align="left">{post.feedbackId}</TableCell>
                <TableCell align="center">{post.email}</TableCell>
                <TableCell align="center">{post.feedbackDate}</TableCell>
                <TableCell align="center">{post.query}</TableCell>
                <TableCell align="center">{post.rating}</TableCell>
                <TableCell align="center">{post.userId}</TableCell>
                <TableCell align="right">
                      <Button variant="outlined" startIcon={<DoneIcon/>} onClick={() => handleDelete(post.complaintId)}>
                            Delete
                      </Button>
                </TableCell>
           </TableRow>
         ))}
       </TableBody>
     </Table>
   </TableContainer>
 );
}
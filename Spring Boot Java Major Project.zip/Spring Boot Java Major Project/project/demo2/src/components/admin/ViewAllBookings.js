import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import React,{ useState, useEffect }  from 'react';
import axios from 'axios';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import BookTicket from "./BookTicket";


  
export default function ViewAllBookings() {
 const [data, setData] = useState([]);
  
 useEffect(() => {
   axios
     .get("http://localhost:8082/getAllBooking")
     .then((res) => {
       setData(res.data);
     })
     .catch((error) => {
       console.log(error);
     });
 }, []);
  
 return (
  <div>
  <BookTicket/>
   <TableContainer component={Paper}>
     <Table aria-label="simple table" stickyHeader>
       <TableHead>
         <TableRow>
           <TableCell align="left">Booking Id</TableCell>
           <TableCell align="center">Date</TableCell>
           <TableCell align="center">Seats Booked</TableCell>
           <TableCell align="center">Booked by (User ID)</TableCell>
           <TableCell align="right">On Flight</TableCell>
         </TableRow>
       </TableHead>
       <TableBody>
         {data.map((post) => (
           <TableRow key={post.bookingId}>
                <TableCell align="left">{post.bookingId}</TableCell>
                <TableCell align="center">{post.bookingDate}</TableCell>
                <TableCell align="center">{post.countPassenger}</TableCell>
                <TableCell align="center">{post.userId}</TableCell>
                <TableCell align="right">{post.flightId}</TableCell>
           </TableRow>
         ))}
       </TableBody>
     </Table>
   </TableContainer>
   </div>
 );
}
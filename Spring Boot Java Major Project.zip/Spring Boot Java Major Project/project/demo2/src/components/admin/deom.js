import React from 'react'

     // This is trial
      $(document).ready(function(){
        $(display)).click(function(){{document.getElementById("show").innerHTML += "Hi man" ;}});
       });
      //


function deom() {
  return (
    <div>
        
        <Button id="display">Add A Flight</Button>
<div id="show"></div>

    </div>
  )
}

export default deom
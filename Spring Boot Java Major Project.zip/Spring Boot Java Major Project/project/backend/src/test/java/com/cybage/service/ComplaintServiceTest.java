package com.cybage.service;

class ComplaintServiceTest {

//	@Test
//	void testAddComplaint() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testGetAllCompalaint() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testGetComplaintById() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testUpdateComplaint() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testDeleteComplaint() {
//		fail("Not yet implemented");
//	}

}

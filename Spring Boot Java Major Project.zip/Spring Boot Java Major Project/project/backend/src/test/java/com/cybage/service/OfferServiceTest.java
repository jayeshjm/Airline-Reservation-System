package com.cybage.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cybage.model.Offer;
import com.cybage.repository.OfferRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
class OfferServiceTest {

	@Autowired
	private OfferService offerService;
	
	@MockBean
	private OfferRepository offerRepository;
	
	@Test
	void testAddOffer() {
		Offer offer = new Offer(1, "holi", "offer20", 200);
		Mockito.when(offerRepository.save(offer)).thenReturn(offer);
		assertThat(offer.getOfferID()==1);
		assertThat(offer!=null);
	}

	@Test
	void testGetAllOffer() {
		Offer offer1 = new Offer(2, "sairat", "zingaat", 150);
		Offer offer2= new Offer(3, "diwali", "hungama", 230);
		List<Offer> offerList= new ArrayList<>();
		offerList.add(offer1);
		offerList.add(offer2);
		
		Mockito.when(offerRepository.findAll()).thenReturn(offerList);
		assertThat(offerService.getAllOffer()).isEqualTo(offerList);
	}

	

	@Test
	void testUpdateOffer() {
		Offer offer = new Offer(2, "sairat", "zingaat", 150);
		assertThat(offer.getOfferID()>0);
		Mockito.when(offerRepository.getById((int)1)).thenReturn(offer);
		offer.setDiscount(250);
		offer.setCoupon("bahubali");	
		Mockito.when(offerRepository.save(offer)).thenReturn(offer);
//		assertThat(offerService.updateOffer(2, offer)).isEqualTo(offer);
	}

	
	@Test
	void testDeleteOffer() {
		Offer offer = new Offer(2, "sairat", "zingaat", 150);
		assertThat(offer.getOfferID()>0);
		Mockito.when(offerRepository.getById((int)1)).thenReturn(offer);
	}

//	@Test
//	void testGetofferById() {
//		fail("Not yet implemented");
//	}
}

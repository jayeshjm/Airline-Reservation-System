package com.cybage.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cybage.model.Booking;
import com.cybage.repository.BookingRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
class BookingServiceTest {

	@Autowired
	private BookingService bookService;

	@MockBean
	private BookingRepository bookingRepository;

	@Test
	void testAddBooking() {
		Booking booking = new Booking(30, "2022-04-25T18:41:37.760Z", 10000, 3, "Lavkesh", "ram", "manya", null, null, null);
		Mockito.when(bookingRepository.save(booking)).thenReturn(booking);
		assertThat(booking.getBookingId()==30);
		assertThat(booking!=null);
	}

	@Test
	void testGetAllBooking() {
		Booking booking1 = new Booking(30, "2022-04-25T18:41:37.760Z", 10000, 3, "Lavkesh", "ram", "manya", null, null, null);
		Booking booking2 = new Booking(45, "2022-04-27T13:07:53.488Z", 2250, 3, "shadab", "shadab", "shadab", null, null, null);
		List<Booking> bookingList=new ArrayList<>();
		bookingList.add(booking1);
		bookingList.add(booking2);
		Mockito.when(bookingRepository.findAll()).thenReturn(bookingList);
		assertThat(bookService.getAllBooking()).isEqualTo(bookingList);
	}

	
	@Test
	void testUpdateBooking() {
		Booking booking = new Booking(30, "2022-04-25T18:41:37.760Z", 10000, 3, "Lavkesh", "ram", "manya", null, null, null);
		assertThat(booking.getBookingId()>0);
		Mockito.when(bookingRepository.getById((int)1)).thenReturn(booking);
		booking.setAmount(5000);
		booking.setCountPassenger(2);
		Mockito.when(bookingRepository.save(booking)).thenReturn(booking);
	}

	@Test
	void testDeleteBooking() {
		Booking booking = new Booking(30, "2022-04-25T18:41:37.760Z", 10000, 3, "Lavkesh", "ram", "manya", null, null, null);
		assertThat(booking.getBookingId()>0);
		Mockito.when(bookingRepository.getById((int)1)).thenReturn(booking);
	}
	
//	@Test
//	void testGetBookingById() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testGetBookingByUserId() {
//		fail("Not yet implemented");
//	}


}

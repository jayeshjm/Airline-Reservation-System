package com.cybage.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cybage.model.Flight;
import com.cybage.repository.FlightRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
class FlightServiceTest {

	
	
	@Autowired 
	private FlightService flightService;
	
	@MockBean
	private FlightRepository flightRepository;
	
	@Test
	void testAddFlight() {
		Flight flight = new Flight(1, "Vistara", 230, "3.30 pm", "5.30 pm", "afternoon", "2022-04-15", "Mumbai", "Delhi", 750, "refundable", "one way", "economy");
		Mockito.when(flightRepository.save(flight)).thenReturn(flight);
		assertThat(flight.getFlightId()==1);
		assertThat(flight!=null);
		
	}

	@Test
	void testGetAllFlights() {
		Flight flight1 = new Flight(1, "Vistara", 230, "3.30 am", "5.30 am", "afternoon", "2022-04-15", "Mumbai", "Delhi", 750, "refundable", "one way", "economy");
		Flight flight2 = new Flight(2, "Vistara", 147, "6.00 pm", "8.00 pm", "night", "2022-04-25", "Agra", "Chennai", 2000, "refundable", "round trip", "business");
		List<Flight> flightList=new ArrayList<>();
		flightList.add(flight1);
		flightList.add(flight2);
		
		Mockito.when(flightRepository.findAll()).thenReturn(flightList);
		assertThat(flightService.getAllFlights()).isEqualTo(flightList);
	}


	@Test
	void testUpdateFlight() {
		Flight flight = new Flight(1, "Vistara", 230, "3.30 am", "5.30 am", "afternoon", "2022-04-15", "Mumbai", "Delhi", 750, "refundable", "one way", "economy");
	assertThat(flight.getFlightId()>0);
	Mockito.when(flightRepository.getById((int)1)).thenReturn(flight);
	
	flight.setPrice(1000);
	flight.setCapacity(200);
	
	Mockito.when(flightRepository.save(flight)).thenReturn(flight);
	
	}
	
	@Test
	void testDeleteFlight() {
		Flight flight = new Flight(1, "Vistara", 230, "3.30 am", "5.30 am", "afternoon", "2022-04-15", "Mumbai", "Delhi", 750, "refundable", "one way", "economy");
		assertThat(flight.getFlightId()>0);
		Mockito.when(flightRepository.getById((int)1)).thenReturn(flight);
	}

//	@Test
//	void testGetFlightById() {
//		fail("Not yet implemented");
//	}

	
//	@Test
//	void testGetByRoute() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testGetBySchedule() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testGetByDateAndRoute() {
//		fail("Not yet implemented");
//	}

}

package com.cybage.controller;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.dto.BookingDTO;
import com.cybage.exception.RecordNotFoundException;
import com.cybage.model.Booking;
import com.cybage.service.BookingService;
import com.cybage.service.EmailService;

@RestController
@CrossOrigin(origins = "*")
public class BookingController {
	static Logger logger = LogManager.getLogger(BookingController.class);
	@Autowired
	BookingService bookingService;

	@Autowired
	EmailService mailService;

	// Add Booking
	@PostMapping("/addBooking")
	public ResponseEntity<String> addBooking(@RequestBody BookingDTO bookingDto) {
		Booking booking =	bookingService.addBooking(bookingDto);
		logger.info("User Booked ticket");
		mailService.sendEmail(booking);
		return new ResponseEntity<String>("Booking added successfully", HttpStatus.CREATED);
	}

	// Fetch All Booking
	@GetMapping("/getAllBooking")
	public ResponseEntity<List<Booking>> getAllBooking() {
		List<Booking> list = bookingService.getAllBooking();
		logger.info("Admin Saw All Bookings");
		return new ResponseEntity<List<Booking>>(list, HttpStatus.OK);
	}

	// Get Bookings For specific Booking Id
	@GetMapping("/getBooking/{id}")
	public ResponseEntity<Booking> getBooking(@PathVariable("id") int id) {
		Booking booking = bookingService.getBookingById(id);
		if (booking == null) {
			throw new RecordNotFoundException("record not found");
		}
		return new ResponseEntity<Booking>(booking, HttpStatus.FOUND);
	}

	// Update Booking By Booking Id
	@PutMapping("/updateBooking/{id}")
	public ResponseEntity<String> updateBooking(@PathVariable int id, @RequestBody Booking booking) {
		bookingService.updateBooking(id, booking);
		return new ResponseEntity<String>("Booking updated successfully", HttpStatus.OK);
	}

	// For Canceling the Booked Ticket
	@DeleteMapping("/deleteBooking/{id}")
	public ResponseEntity<?> deleteBooking(@PathVariable int id) {
		Booking ticket = bookingService.getBookingById(id);
		logger.info("User Cancelled his Booking");
		bookingService.deleteBooking(id);
		mailService.sendEmailforDeletion(ticket);
		return new ResponseEntity<String>("Booking Cancelled successfully", HttpStatus.FOUND);
	}

	// For User to See all his bookings Fetched According to User Id
	@GetMapping("/getBookings/{userId}")
	public ResponseEntity<List<Booking>> getBookingByUserId(@PathVariable int userId) {
		List<Booking> booking = bookingService.getBookingByUserId(userId);
		if (booking == null) {
			throw new RecordNotFoundException("record not found");
		}
		logger.info("User Saw  All his Bookings");
		return new ResponseEntity<List<Booking>>(bookingService.getBookingByUserId(userId), HttpStatus.OK);
	}

}

package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.model.Feedback;
import com.cybage.repository.FeedbackRepository;

@Service
public class FeedbackService {

	@Autowired
	FeedbackRepository feedbackRepository;

	public void addFeedback(Feedback feedback) {
		feedbackRepository.save(feedback);
	}

	public List<Feedback> getAllOffer() {
		return feedbackRepository.findAll();

	}

	public List<Feedback> getAllFeedbacks() {
		return feedbackRepository.findAll();
	}
}
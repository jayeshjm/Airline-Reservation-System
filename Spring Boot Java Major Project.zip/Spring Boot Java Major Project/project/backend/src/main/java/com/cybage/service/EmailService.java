package com.cybage.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.cybage.model.Booking;
import com.cybage.model.Flight;
import com.cybage.model.User;

@Service
public class EmailService {
	@Autowired
	private JavaMailSender mailSender;
	
	@Autowired
	UserService userService;
	@Autowired
	FlightService flightService;
	
//	otp method()
	public int sendOTP(String email) {
		int otp = 0;
		try {
			SimpleMailMessage message = new SimpleMailMessage();
			message.setFrom("Trng2@evolvingsols.com");
			message.setTo(email);
			otp = (int) (Math.floor(Math.random() * 1000000));
			message.setText("Your OTP for login is " + otp);
			message.setSubject("OTP for Online Flight Reservation System.");
			System.out.println("mail() before sent check on console");

			mailSender.send(message);
			System.out.println("mail() after sent check on console");
		} catch (MailException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return otp;
	}
	
//	send email after booking
	public void sendEmail(Booking customer) throws MailException {
       User user=userService.getUserById(customer.getUser().getUserId());
       Flight flight=flightService.getFlightById(customer.getFlight().getFlightId());
		SimpleMailMessage mail = new SimpleMailMessage();
		String email = user.getEmail();
		mail.setFrom("Trng2@evolvingsols.com");
		mail.setTo(email);
		mail.setSubject("Ticket booking status");
		mail.setText("Dear  " + user.getName()
				+ "\n This email is to inform you that your ticket has been booked on : " + customer.getBookingDate()
				+ "\n for flight details are as follows \n (1) departure date : " + flight.getFlightDate()
				+ "\n (2) Timeslot : " + flight.getDepartureTime()
				+ "\n Please be present on time for your flight.\n Thank you");
		mailSender.send(mail);
		}   
	
	
//	send mail after cancelling ticket
	public void sendEmailforDeletion(Booking customer) throws MailException {

		SimpleMailMessage mail = new SimpleMailMessage();
		String email = customer.getUser().getEmail();
		mail.setFrom("Trng2@evolvingsols.com");
		mail.setTo(email);
		mail.setSubject("Ticket booking status");
		mail.setText("Dear  "+customer.getUser().getName()+"\n This email is to inform you that your ticket has been cancelled.\n\n Thank you");
		mailSender.send(mail);
	}
}

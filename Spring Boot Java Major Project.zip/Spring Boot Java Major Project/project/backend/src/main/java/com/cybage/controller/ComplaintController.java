package com.cybage.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.exception.RecordNotFoundException;
import com.cybage.model.Complaint;

import com.cybage.service.ComplaintService;

@RestController
@CrossOrigin(origins="*")
public class ComplaintController {
	static Logger logger=LogManager.getLogger(BookingController.class);
	@Autowired
ComplaintService complaintService;
	
	
	@PostMapping("/addComplaint")
	public ResponseEntity<String> addComplaint(@RequestBody Complaint complaint){
		complaintService.addComplaint(complaint);
		logger.info("User Added Complaint");
		return new ResponseEntity<String>("complaint added successfully",HttpStatus.CREATED);
		
	}
	
	@GetMapping("/getAllComplaint")
	public ResponseEntity<List<Complaint>> getAllComplaint(){	
		logger.info("Admin Accesed all  Complaints");
		  return new ResponseEntity<List<Complaint>>(complaintService.getAllCompalaint(),HttpStatus.OK);	
	}
	
	
	@GetMapping("/getComplaint/{id}")
	public ResponseEntity<Complaint> getComplaint(@PathVariable("id") int id){
	  Complaint complaint=complaintService.getComplaintById(id);
	  if(complaint==null)
	  {
		  throw new RecordNotFoundException("record not found");
	  }
		 return new ResponseEntity<Complaint>(complaint,HttpStatus.FOUND);
	}
	

	@PutMapping("/updateComplaint/{id}")
	public ResponseEntity<String> updateComplaint(@PathVariable int id,@RequestBody Complaint complaint)
	{
		  complaintService.updateComplaint(complaint);
		  logger.info("Complaint Updated by admin");
		  return new ResponseEntity<String>("complaint updated successfully",HttpStatus.OK);  
	}
	
	
	 @DeleteMapping("/deleteComplaint/{id}")
		public ResponseEntity<String> deleteComplaint(@PathVariable int id){	
		complaintService.deleteComplaint(id);
		logger.info("Complaint Deleted by admin");
		  return new ResponseEntity<String>("Deleted successfully",HttpStatus.FOUND);
	}
}

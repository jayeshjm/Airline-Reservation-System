package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.model.Complaint;
import com.cybage.repository.ComplaintRepositry;

@Service
public class ComplaintService   {
  
	@Autowired
	ComplaintRepositry complaintRepositry;
	
	public void addComplaint(Complaint complaint) {
		complaintRepositry.save(complaint);
	}
	
	public List<Complaint> getAllCompalaint(){
		return complaintRepositry.findAll();
		
	}
	
	public Complaint getComplaintById(int id)
	{
		Complaint complaint=complaintRepositry.findById(id).orElse(null);
		return complaint;
		
	}
	
	public void updateComplaint(Complaint complaint ) {
		complaint.setAction("Done");

		complaintRepositry.save(complaint);
	}
	

	
	public void deleteComplaint(int id) {
		System.out.println("id"+id);
		complaintRepositry.deleteById(id);
	}

	
	}

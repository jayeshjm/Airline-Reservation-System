package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.dto.BookingDTO;
import com.cybage.model.Booking;
import com.cybage.model.Flight;
import com.cybage.model.User;
import com.cybage.repository.BookingRepository;
import com.cybage.repository.FlightRepository;
import com.cybage.repository.UserRepository;

@Service
public class BookingService {
	
	
	@Autowired
	BookingRepository bookingRepository;
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	FlightRepository flightRepository;
	

	
	public Booking addBooking(BookingDTO bookingDto) {
		User user = userRepository.getById(bookingDto.getUserId());
		Flight flight = flightRepository.getById(bookingDto.getFlightId());
		Booking booking = BookingDTO.toBookingEntity(bookingDto , user , flight);
		return bookingRepository.save(booking);
	}
	
	public List<Booking> getAllBooking(){
		return bookingRepository.findAll();
		
	}
	
	public Booking getBookingById(int id)
	{
	Booking booking=bookingRepository.findById(id).orElse(null);
		return booking;
		
	}
	
	public List<Booking> getBookingByUserId(int id)
	{
	List<Booking> booking=bookingRepository.findBookingByUserId(id);
		return booking;
		
	}
	
	
	
	
	
	public void updateBooking(int id,Booking booking ) {
		booking.setBookingId(id);

		bookingRepository.save(booking);
	}
	

	
	public void deleteBooking(int id) {
		System.out.println("id"+id);
		bookingRepository.deleteById(id);
	}

}

package com.cybage.dto;

import com.cybage.model.Booking;
import com.cybage.model.Flight;
import com.cybage.model.User;

public class BookingDTO {

	private int bookingId;
	private String bookingDate;
	private double amount;
	private int countPassenger;
	private String passenger1;
	private String passenger2;
	private String passenger3;
	private int userId;
	private int flightId;

	public BookingDTO() {
		super();
	}

	public BookingDTO(int bookingId, String bookingDate, double amount, int countPassenger, String passenger1,
			String passenger2, String passenger3, int userId, int flightId) {
		super();
		this.bookingId = bookingId;
		this.bookingDate = bookingDate;
		this.amount = amount;
		this.countPassenger = countPassenger;
		this.passenger1 = passenger1;
		this.passenger2 = passenger2;
		this.passenger3 = passenger3;
		this.userId = userId;
		this.flightId = flightId;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public String getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public int getCountPassenger() {
		return countPassenger;
	}

	public void setCountPassenger(int countPassenger) {
		this.countPassenger = countPassenger;
	}

	public String getPassenger1() {
		return passenger1;
	}

	public void setPassenger1(String passenger1) {
		this.passenger1 = passenger1;
	}

	public String getPassenger2() {
		return passenger2;
	}

	public void setPassenger2(String passenger2) {
		this.passenger2 = passenger2;
	}

	public String getPassenger3() {
		return passenger3;
	}

	public void setPassenger3(String passenger3) {
		this.passenger3 = passenger3;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	@Override
	public String toString() {
		return "BookingDTO [bookingId=" + bookingId + ", bookingDate=" + bookingDate + ", amount=" + amount
				+ ", countPassenger=" + countPassenger + ", passenger1=" + passenger1 + ", passenger2=" + passenger2
				+ ", passenger3=" + passenger3 + ", userId=" + userId + ", flightId=" + flightId + "]";
	}
	
	public static Booking toBookingEntity(BookingDTO bookingDto , User user , Flight flight) {
		Booking booking = new Booking();
		booking.setAmount(bookingDto.getAmount());
		booking.setBookingDate(bookingDto.getBookingDate());
		booking.setCountPassenger(bookingDto.getCountPassenger());
		booking.setPassenger1(bookingDto.getPassenger1());
		booking.setPassenger2(bookingDto.getPassenger2());
		booking.setPassenger3(bookingDto.getPassenger3());
		booking.setUser(user);
		booking.setFlight(flight);
		return booking;
	}

}

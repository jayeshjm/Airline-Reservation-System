package com.cybage.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "feedback")
public class Feedback {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int feedbackId;
	private String feedbackDate;
	private String email;
	private int rating;
	private String query;

	public Feedback() {
		// TODO Auto-generated constructor stub
	}

	public Feedback(int feedbackId, String feedbackDate, String email, int rating, String query) {
		super();
		this.feedbackId = feedbackId;
		this.feedbackDate = feedbackDate;
		this.email = email;
		this.rating = rating;
		this.query = query;
	}

	public int getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}

	public String getFeedbackDate() {
		return feedbackDate;
	}

	public void setFeedbackDate(String feedbackDate) {
		this.feedbackDate = feedbackDate;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	@Override
	public String toString() {
		return "Feedback [feedbackId=" + feedbackId + ", feedbackDate=" + feedbackDate + ", email=" + email
				+ ", rating=" + rating + ", query=" + query + "]";
	}

}
